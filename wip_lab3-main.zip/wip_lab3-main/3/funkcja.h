// funkcja.h

int phi(long int n);
