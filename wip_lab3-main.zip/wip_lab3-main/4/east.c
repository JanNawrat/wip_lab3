// east.c

#include "agents.h"

void east(struct agent *a)
{
	a->x++;
}
