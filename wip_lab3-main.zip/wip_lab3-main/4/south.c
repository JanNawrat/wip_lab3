// south.c

#include "agents.h"

void south(struct agent *a)
{
	a->y--;
}
