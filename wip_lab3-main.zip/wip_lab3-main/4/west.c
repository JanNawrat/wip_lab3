// west.c

#include "agents.h"

void west(struct agent *a)
{
	a->x--;
}
