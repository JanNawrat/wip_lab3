// north.c

#include "agents.h"

void north(struct agent *a)
{
	a->y++;
}
