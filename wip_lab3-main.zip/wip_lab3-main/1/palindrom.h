// palindrom.h

bool palindrom( char napis[] );
