// f.c

#include <math.h>
#include "funkcja.h"

double f(double x)
{
    return cos(x/2);
}
